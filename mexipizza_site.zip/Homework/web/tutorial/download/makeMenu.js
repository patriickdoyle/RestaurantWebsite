function makeMenu(objList) {
    //create div to return
    var myDiv = document.createElement("div");
    
    //variable holds value of tip
    var tip = 0;
    //public method sets the tip rate
    myDiv.setTip = function (val) {
        if (tip > 1 || tip < 0) {
            console.log("tip must be a decimal between 1 and 0");
            return;
        }
        tip = val;
    }//end setTax

    //create a div to return a summary of search results
    var searchSummary = document.createElement("div");
    myDiv.appendChild(searchSummary);

    //menu should be searchable via the searchbar
    var searchDiv = document.createElement("div");
    searchDiv.classList.add("topnav");

    var searchContainer = document.createElement("div");
    searchContainer.classList.add("search-container");

    var input = document.createElement("input");
    input.classList.add("topnav");
    input.placeholder = "Search..";
    input.name = "search";
    input.type = "text";
    searchContainer.appendChild(input);

    var submitButton = document.createElement("BUTTON");
    submitButton.classList.add("topnav");
    submitButton.innerText = "Submit";
    submitButton.type = "submit";
    searchContainer.appendChild(submitButton);

    searchDiv.appendChild(searchContainer);
    myDiv.appendChild(searchDiv);

    //create array to hold itemDivs
    var items = new Array();

    //create the users cart
    var cart = new Array();

    //create divs for checkout summary
    var checkoutHeading = document.createElement("h3");
    var checkoutSummary = document.createElement("p");
    var totalSummary = document.createElement("p");

    //loop through the object list
    for (var i = 0; i < objList.length; i++) {
        console.log(objList[i].name);
        //output clickable menu item to the page
        var itemDiv = document.createElement("div");
        myDiv.appendChild(itemDiv);
        itemDiv.innerHTML = objList[i].name;
        items[i] = itemDiv;

        //when itemDiv is clicked: create + trigger the modal
        items[i].onclick = function () {
            //create modal box for menu item
            var modal = document.createElement("div");
            modal.classList.add("modal");

            var modalContent = document.createElement("div");
            modalContent.classList.add("modal-content");

            var span = document.createElement("span");
            span.classList.add("close");
            modalContent.appendChild(span);

            var modalData = document.createElement("p");
            //find the correct item in objList and use its data in the modal
            for (var i = 0; i < objList.length; i++) {

                if (this.innerHTML === objList[i].name) {
                    modalData.innerHTML = "Name :" + objList[i].name + "<br />" + "Price: $" + objList[i].price +
                            "<br />" + objList[i].desc;
                    break;
                }//end if
            }//end for

            modalContent.appendChild(modalData);

            //create buttons
            var cartButton = document.createElement("BUTTON");
            cartButton.innerText = "Add to Cart";
            modalContent.appendChild(cartButton);

            var checkoutButton = document.createElement("BUTTON");
            checkoutButton.innerText = "Checkout";
            modalContent.appendChild(checkoutButton);

            //create star rating feature
            var star1 = document.createElement("span");
            var star2 = document.createElement("span");
            var star3 = document.createElement("span");
            var star4 = document.createElement("span");
            var star5 = document.createElement("span");

            const rating = [star1, star2, star3, star4, star5];

            for (var j = 0; j < 5; j++) {
                if (j < objList[i].rating) {
                    rating[j].classList.add("fa", "fa-star", "checked");
                }//end if
                else {
                    rating[j].classList.add("fa", "fa-star");
                }//end else
                modalContent.appendChild(rating[j]);
            }//end for

            modal.appendChild(modalContent);
            myDiv.appendChild(modal);
            modal.style.display = "block";
            display();

            // When the user clicks on <span> (x), close the modal
            span.onclick = function () {
                modal.style.display = "none";
            };
            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function (event) {
                if (event.target === modal) {
                    modal.style.display = "none";
                }
            };

            //code to run when buttons are clicked
            cartButton.onclick = function () {
                //add the object to the cart array
                cart.push(objList[i]);
            };

            checkoutButton.onclick = function () {
                // Create our currency formatter.
                var formatter = new Intl.NumberFormat('en-US', {
                    style: 'currency',
                    currency: 'USD'
                });

                //variables to hold data about the bill
                var total = 0;

                //create a bolded header for aesthetic purposes
                checkoutHeading.innerText = "Order Summary";
                myDiv.appendChild(checkoutHeading);

                checkoutSummary.innerText = "";
                
                //if there's nothing in the cart, nothing to do
                if (cart.length === 0) {
                    checkoutSummary.innerText = "There's nothing in your cart";
                    myDiv.appendChild(checkoutSummary);
                } else {
                    for (var i = 0; i < cart.length; i++) {
                        // display contents of the cart
                        checkoutSummary.innerText += cart[i].name + " " + formatter.format(cart[i].price) + "\n";
                        myDiv.appendChild(checkoutSummary);
                        
                        //calculate total
                        total += cart[i].price;
                        
                    }//end for
                }
                
                totalSummary.innerText = "Subtotal: " + formatter.format(total) + "\n" +
                        "\n" + tip + "% tip: " + formatter.format(tip * total) + " || Total: " + formatter.format((tip * total) + total);
                myDiv.appendChild(totalSummary);
                
                //clear the cart
                var len = cart.length;
                for (var i = 0; i <= len; i++) {
                    cart.pop();
                }

            };//end checkoutbutton onclick

        };//end itemDiv.onClick

        var display = function () {

        };

    }//end for

    submitButton.onclick = function () {
        searchSummary.innerHTML = "";
        var bool = false; //change to true if a match is found

        //if someone clicks submit with no text, restore the page
        if (String(input.value) === "") {
            for (var i = 0; i < items.length; i++) {
                items[i].style.visibility = "visible";
            }//end for
            return;
        }//end if
        for (var i = 0; i < items.length; i++) {
            if (objList[i].name.toLowerCase() !== String(input.value).toLowerCase()) {
                items[i].style.visibility = "hidden";
                if (i === (items.length - 1) && bool === false) {
                    //only display after the last item has been checked
                    searchSummary.innerHTML = "No results found.";
                }//end if
            } else {
                bool = true;
                if (items[i].style.visibility === "hidden") {
                    items[i].style.visibility = "visible";
                }//end if
            }//end else
        }//end for  
    };//end submitButton onclick()
    return myDiv;
}//end makeWidget





