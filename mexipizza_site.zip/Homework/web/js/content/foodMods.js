var foodMods = {}; // Update Solutioin Spring 2022

(function () {  // This is an IIFE, an immediately executing function.
    // It is an anonymous function that runs once (and only once) at page load time.
    // Put in here any private functions to be shared (e.g., by webUserMods.insert 
    // and webUserMods.update). 

    //alert("I am an IIFE!"); // runs only at page load time...

    // All variables declared in this area (before webUserMods.insert) 
    // are avilable to webUserMods.insert AND webUserMods.update. 


    var fields = [
        {
            fieldName: "foodId",
            prompt: "Food Id",
            disabled: true
        },
        {
            fieldName: "foodName",
            prompt: "Food Name"  // if you forget to add the prompt, it uses the field name as prompt
        },
        
        {
            fieldName: "foodImg",
            prompt: "Image URL"
        },
        {
            fieldName: "foodDatefooded",
            prompt: "Date fooded"
        },
        {
            fieldName: "foodRating",
            prompt: "Rating"
        },
        {
            fieldName: "foodDescription",
            prompt: "Description"
        },
        {
            fieldName: "webUserId",
            prompt: "User Id",
            pickList: true
        }
    ];

    var component = document.createElement("div");

    // call reusable function to make an edit area component
    var foodEditArea = MakeEditArea({
        areaTitle: "Will Get Changed...",
        fieldDefn: fields
    });
    component.appendChild(foodEditArea);

    foodMods.insert = function () {

        // Create UI for insert (using the shared DOM elements just above, in the IIFE).
        foodEditArea.areaTitle.innerHTML = "New Food";
        foodEditArea.blankInputs();
        foodEditArea.button.innerHTML = "Insert Save";
        foodEditArea.formMsg.innerHTML = ""; // wipe out any old message

        // *********************************************************
        // Add role pick list to userEditArea (the userRoleId row of the HTML table). 
        // I wanted to show how you could get fresh list of user roles from the DB 
        // with each user insert since you'll need to do something like this for 
        // insert "other" (get a fresh copy of users for the webuser FK from "other"). 
        ajax("webAPIs/getUserIdsAPI.jsp", processIds, foodEditArea.formMsg);

        function processIds(obj) {
            console.log("process ids:" + obj);
            // obj is the list of roles returned by the getRolesAPI.jsp
            if (obj.dbError.length > 0) {
                foodEditArea["webUserId"].errorTd.innerHTML +=
                        "Programmer Error: Cannot Create Id Pick List... " +
                        obj.dbError;
            } else {
                var selectTag = Utils.makePickList({
                    list: obj.idList,
                    idProp: "webUserId",
                    displayProp: "userEmail"
                });

                // put the Role select tag (just made) into the inputTd property 
                // of the UserRoleId row of the HTML table 
                foodEditArea["webUserId"].inputTd.innerHTML = "";
                foodEditArea["webUserId"].inputTd.appendChild(selectTag);
            }
        } // processRoles (ajax call back function 
        // *********************************************************

        foodEditArea.button.onclick = function () {  // INSERT SAVE

            // inputObj is an object with all user input values. 
            var foodInputObj = foodEditArea.getDataFromUI();

            // Place the role (selected option of the select tag) into the userInputObj
            var idSelect = foodEditArea["webUserId"].inputTd.getElementsByTagName("select")[0];
            foodInputObj.webUserId = idSelect.options[idSelect.selectedIndex].value;

            // convert userInputObj to JSON and URL encode (e.g., turns space to %20), 
            // URL encode so that the server does not reject URL for security reasons.
            var urlParams = encodeURIComponent(JSON.stringify(foodInputObj));
            console.log("Insert Save URL params: " + urlParams);

            ajax("webAPIs/insertFoodAPI.jsp?jsonData=" + urlParams, reportInsert, foodEditArea.formMsg);

            function reportInsert(obj) {

                // obj is the error message object (passed back from the Insert API).
                // obj (conveniently) has its fields named exactly the same as the input data was named. 

                console.log("Insert API response (error message object) on next line");
                console.log(obj);

                // write all the error messages to the UI (into the third column for each row).
                foodEditArea.writeErrorObjToUI(obj);

                if (obj.errorMsg.length === 0) { // success
                    foodEditArea.formMsg.innerHTML = "Record successfully inserted.";
                } else {
                    if (obj.errorMsg === " PrepStatement: Exception in executeUpdate(). Sql is INSERT INTO food (food_id, food_name, web_user_id) values (?,?,?). Error Msg: Duplicate entry 'Burrito' for key 'food_name_UNIQUE'") {
                        obj.errorMsg = "Food Name already taken. Please try again.";
                    }
                    foodEditArea.formMsg.innerHTML = obj.errorMsg;
                }
            }
        };

        return component;
    }; // webUserMods.insert



    // NOTE: this is the first content generating component that takes an input 
    // parameter. So we now use NavRouter parameters (NavRouter extracts parameter 
    // from the link (if there is one) and passes that parameter to the content 
    // generating function (that's been specified in the routing table). 
    // Example:  if the URL has this: userUpdate/4. 
    // The NavRouter extracts the 4 from the URL and passes that 4 to the content
    // generating function that's associated with link "#/userUpdate".

    // This function gets a web_user record (by id) then places that data into the Edit UI. .
    foodMods.update = function (foodId) {

        foodEditArea.areaTitle.innerHTML = "Update Food";
        foodEditArea.blankInputs();
        foodEditArea.button.innerHTML = "Update Save";
        foodEditArea.formMsg.innerHTML = ""; // wipe out any old message

        console.log("food.update called with foodId " + foodId);

        // get the web user record with the given webUserId
        ajax("webAPIs/getFoodByIdAPI.jsp?foodId=" + foodId, gotRecordById, foodEditArea.formMsg);

        // webUserObj is the output of getUserByIdAPI.jsp
        function gotRecordById(foodObj) {

            foodEditArea.writeDbValuesToUI(foodObj);

            // get an updated list of roles (even though this does not change often), 
            // just so you see how to get a fresh role list with each web user insert.
            ajax("webAPIs/getUserIdsAPI.jsp", processIds, foodEditArea.formMsg);

            // obj is the output from getRolesAPI.jsp
            function processIds(obj) {

                if (obj.dbError.length > 0) {
                    foodEditArea["webUserId"].errorTd.innerHTML += "Programmer Error: Cannot Create Id Pick List";
                } else {
                    console.log("webUserId is " + foodObj.webUserId);
                    var selectTag = Utils.makePickList({
                        list: obj.idList,
                        idProp: "webUserId",
                        displayProp: "userEmail",
                        selectedKey: foodObj.webUserId  // key that is to be pre-selected (optional)
                    });

                    // Put the User Role Select Tag (just created) into the input column of the 
                    // userRoleId row of the HTML table we're using for data entry.
                    foodEditArea["webUserId"].inputTd.innerHTML = "";
                    foodEditArea["webUserId"].inputTd.appendChild(selectTag);
                }
            } // processRoles
        } // gotRecordById


        foodEditArea.button.onclick = function () { // Update Save

            // collect all the user input values into an object. 
            var foodInputObj = foodEditArea.getDataFromUI();

            // find the user role selected from the select tag (and put it into userInputObj).
            var idSelect = foodEditArea["webUserId"].inputTd.getElementsByTagName("select")[0];
            foodInputObj.webUserId = idSelect.options[idSelect.selectedIndex].value;

            // convert userInputObj to JSON and URL encode (turns space to %20), 
            // so server does not reject URL for security reasons.
            var urlParams = encodeURIComponent(JSON.stringify(foodInputObj));
            console.log("Update Save URL params: " + urlParams);

            ajax("webAPIs/updateFoodAPI.jsp?jsonData=" + urlParams, reportUpdate, foodEditArea.formMsg);

            function reportUpdate(jsErrorObj) {

                foodEditArea.writeErrorObjToUI(jsErrorObj);

                // jsErrorObj is a StringData object full of error messages 
                // (using same field names). 

                if (jsErrorObj.errorMsg.length === 0) { // success
                    foodEditArea.formMsg.innerHTML = "Record successfully updated. ";
                } else {
                    foodEditArea.formMsg.innerHTML = jsErrorObj.errorMsg;
                }
            }
        }; //updateSave submit button
        

        return component;

    }; // end of webUsers.update
    
    foodMods.delete = function (foodId) {
        var component = document.createElement("div");
        var prompt = document.createElement("div");
        prompt.innerHTML = "Are you sure you want to delete?";
        component.appendChild(prompt);
        var button = document.createElement("button");
        button.innerText = "Confirm";
        component.appendChild(button);
        var msg = document.createElement("td");
        msg.innerHTML = "";
        component.appendChild(msg);
        var error = document.createElement("td");
        error.innerHTML = "";
        component.appendChild(error);
        console.log("foodMods.delete called with foodId " + foodId);

        ajax("webAPIs/getFoodByIdAPI.jsp?foodId=" + foodId, gotFoodById, msg);
        function gotFoodById(foodObj) {

            //foodEditArea.writeDbValuesToUI(foodObj);

            // get an updated list of roles (even though this does not change often), 
            // just so you see how to get a fresh role list with each web user insert.
            ajax("webAPIs/getFoodByIdAPI.jsp", processFood, msg);
         

            function processFood(obj) {

            console.log("foodId is " + foodObj.foodId);
             
            } 
        } 


        button.onclick = function () { // Delete
            
            ajax("webAPIs/deleteFoodAPI.jsp?deleteId=" + foodId, deleteFood, msg);
            
            function deleteFood(jsErrorObj) {

                if (jsErrorObj.errorMsg.length === 0) { // success
                    msg.innerHTML = "Record successfully deleted. ";
                } else {
                    msg.innerHTML = jsErrorObj.errorMsg;
                }
            }
        }; 

        return component;

    };  

}());  // end of the IIFE