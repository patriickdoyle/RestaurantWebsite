function liveFoodContent() {

    "use strict"; // turn off the "auto variable declaration" feature of the browser.
    // So, if we mispell a variable name, the browser will not auto-declare a new variable. 

    // ***** THE FIRST COMPONENT IS DONE FOR YOU *****

    var myDiv1 = document.createElement("div");
    document.getElementById("userContainer").appendChild(myDiv1);

    // Make AJAX call to read food.json and if the call was successful, run function
    // processFoodData, otherwise, put an error message in the mydiv1 DOM element. 
    ajax('webAPIs/listFoodAPI.jsp', processFoodData, myDiv1);
    console.log("got past ajax call");


    function processFoodData(obj) { // callback function

        if (obj.dbError.length > 0) {
            myDiv1.innerHTML = obj.dbError;
            return;
        }
        var list = obj.foodList;
        // turn this list of objects into click sort-able filterable HTML table (component)

        // now foodList has been populated with data from the AJAX call to file food.json
        console.log("food list (in processFoodData) on next line - open triangle to see data");
        console.log(list);

        // Create new object list where all properties are <td> elements
        var newFoodList = [];
        for (var i = 0; i < list.length; i++) {
            newFoodList[i] = {};
            newFoodList[i].Food_Id = SortableTableUtils.makeNumber(list[i].foodId);
            newFoodList[i].Food_Name = SortableTableUtils.makeText(list[i].foodName);
            console.log(list[i].foodImg);
            newFoodList[i]._Image = SortableTableUtils.makeImage(list[i].foodImg, "4rem");
            newFoodList[i].Food_DateOrdered = SortableTableUtils.makeDate(list[i].foodDateOrdered);
            newFoodList[i].Food_Rating = SortableTableUtils.makeNumber(list[i].foodRating);
            newFoodList[i].Food_Description = SortableTableUtils.makeText(list[i].foodDescription);
            newFoodList[i].Web_UserId = SortableTableUtils.makeNumber(list[i].webUserId);
            newFoodList[i].User_Email = SortableTableUtils.makeText(list[i].userEmail);
            newFoodList[i].User_Password = SortableTableUtils.makeText(list[i].userPassword);
            
            //update column
            newFoodList[i]._Update = SortableTableUtils.makeLink(
                    "<img src='icons/more_icons/edit.png' style='width:1rem' />",
                    '#/foodUpdate/' + list[i].foodId);
                    
            //delete column
            newFoodList[i]._Delete = SortableTableUtils.makeLink(
                    "<img src='icons/more_icons/delete.png' style='width:1rem' />",
                    '#/foodDelete/' + list[i].foodId);
        }

        // MakeTableBetter expects all properties to be <td> elements.
        var myReport1 = MakeClickSortTable("Food List", newFoodList, "Food_Id", "icons/sortUpDown16.png");
        myReport1.classList.add("clickSort");
        myDiv1.appendChild(myReport1);

    } // processFoodData
    return myDiv1;
}

