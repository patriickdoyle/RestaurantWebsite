package model.food;

import dbUtils.DbConn;
import dbUtils.FormatUtils;
import dbUtils.PrepStatement;
import dbUtils.ValidationUtils;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DbMods {

    public static StringData findById(DbConn dbc, String id) {
        /*
        "SELECT web_user_id, user_email, user_password, membership_fee, birthday, image, "
                    + "web_user.user_role_id, user_role_type "
                    + "FROM web_user, user_role WHERE web_user.user_role_id = user_role.user_role_id "
                    + "AND web_user_id = ?";
        */

        // The find API needs to represent three cases: found web_user, not found, db error. 
        StringData sd = new StringData();
        System.out.println("check: " + id);
        try {
            String sql = "SELECT food_id, food_name, food_img, food_date_ordered, food_rating, food_description, "
                    + "web_user_id "
                    + "FROM food WHERE food_id = ?";

            PreparedStatement stmt = dbc.getConn().prepareStatement(sql);

            // Encode the id (that the user typed in) into the select statement, into the first (and only) ? 
            stmt.setString(1, id);

            ResultSet results = stmt.executeQuery();
            if (results.next()) { // id is unique, one or zero records expected in result set

                // plainInteger returns integer converted to string with no commas.
                sd.foodId = FormatUtils.plainInteger(results.getObject("food_id"));
                sd.foodName = FormatUtils.formatString(results.getObject("food_name"));
                sd.foodImg = FormatUtils.formatString(results.getObject("food_img"));
                sd.foodDateOrdered = FormatUtils.formatDate(results.getObject("food_date_ordered"));
                sd.foodRating = FormatUtils.plainInteger(results.getObject("food_rating"));
                sd.foodDescription = FormatUtils.formatString(results.getObject("food_description"));
                sd.webUserId = FormatUtils.plainInteger(results.getObject("web_user_id"));

            } else {
                sd.errorMsg = "Web User Not Found.";
            }
            results.close();
            stmt.close();
        } catch (Exception e) {
            sd.errorMsg = "Exception thrown in DbMods.findById(): " + e.getMessage();
        }
        return sd;

    } // findById

    /*sd.foodId = FormatUtils.plainInteger(results.getObject("food_id"));
                sd.foodName = FormatUtils.formatString(results.getObject("food_name"));
                sd.foodImg = FormatUtils.formatString(results.getObject("food_img"));
                sd.foodDateOrdered = FormatUtils.formatDate(results.getObject("food_date_ordered"));
                sd.foodRating = FormatUtils.plainInteger(results.getObject("food_rating"));
                sd.foodDescription = FormatUtils.formatString(results.getObject("food_description"));*/
    private static StringData validate(StringData inputData) {

        StringData errorMsgs = new StringData();

        // Validation
        //errorMsgs.userEmail = ValidationUtils.stringValidationMsg(inputData.userEmail, 45, true);
        //errorMsgs.userPassword = ValidationUtils.stringValidationMsg(inputData.userPassword, 45, true);
        //if (inputData.userPassword.compareTo(inputData.userPassword2) != 0) { // case sensative comparison
        //  errorMsgs.userPassword2 = "Both passwords must match";
        //}
        errorMsgs.foodImg = ValidationUtils.stringValidationMsg(inputData.foodImg, 300, false);

        errorMsgs.foodDateOrdered = ValidationUtils.dateValidationMsg(inputData.foodDateOrdered, false);
        errorMsgs.foodId = ValidationUtils.integerValidationMsg(inputData.foodId, false);
        errorMsgs.foodName = ValidationUtils.stringValidationMsg(inputData.foodName, 300, false);
        errorMsgs.foodRating = ValidationUtils.integerValidationMsg(inputData.foodRating, false);
        errorMsgs.foodDescription = ValidationUtils.stringValidationMsg(inputData.foodDescription, 300, true);
        return errorMsgs;
    } // validate 

    public static model.food.StringData update(StringData inputData, DbConn dbc) {

        StringData errorMsgs = new StringData();
        errorMsgs = validate(inputData);
        if (errorMsgs.getCharacterCount() > 0) {  // at least one field has an error, don't go any further.
            errorMsgs.errorMsg = "Please try again";
            return errorMsgs;

        } else { // all fields passed validation

            /*
                "SELECT food_id, food_name, food_img, food_date_ordered, food_rating, food_description,"
                    + "food.web_user_id"
                    + "FROM web_user, food WHERE web_user.web_user_id = food.web_user_id "
                    + "AND food_id = ?"; 
             */
            //String sql = "UPDATE web_user SET user_email=?, user_password=?, image= ?, membership_fee=?, birthday=?, "
              //      + "user_role_id=? WHERE web_user_id = ?";
            String sql = "UPDATE food SET food_name=?, food_img=?, food_date_ordered= ?, food_rating=?, food_description=?, "
                    + "web_user_id=? WHERE food_id = ?";

            // PrepStatement is Sally's wrapper class for java.sql.PreparedStatement
            // Only difference is that Sally's class takes care of encoding null 
            // when necessary. And it also System.out.prints exception error messages.
            PrepStatement pStatement = new PrepStatement(dbc, sql);
            
            // Encode string values into the prepared statement (wrapper class).
            pStatement.setString(1, inputData.foodName); // string type is simple
            pStatement.setString(2, inputData.foodImg);
            pStatement.setDate(3, ValidationUtils.dateConversion(inputData.foodDateOrdered));
            pStatement.setInt(4, ValidationUtils.integerConversion(inputData.foodRating));
            pStatement.setString(5, inputData.foodDescription);
            pStatement.setInt(6, ValidationUtils.integerConversion(inputData.webUserId));
            pStatement.setInt(7, ValidationUtils.integerConversion(inputData.foodId));
            // here the SQL statement is actually executed
            int numRows = pStatement.executeUpdate();

            // This will return empty string if all went well, else all error messages.
            errorMsgs.errorMsg = pStatement.getErrorMsg();
            if (errorMsgs.errorMsg.length() == 0) {
                if (numRows == 1) {
                    errorMsgs.errorMsg = ""; // This means SUCCESS. Let the user interface decide how to tell this to the user.
                } else {
                    // probably never get here unless you forgot your WHERE clause and did a bulk sql update.
                    errorMsgs.errorMsg = numRows + " records were updated (expected to update one record).";
                }
            } else if (errorMsgs.errorMsg.contains("foreign key")) {
                errorMsgs.errorMsg = "Invalid User Role Id";
            } else if (errorMsgs.errorMsg.contains("Duplicate entry")) {
                errorMsgs.errorMsg = "That email address is already taken";
            }

        } // customerId is not null and not empty string.
        return errorMsgs;
    } // update
    
    public static StringData insert(StringData inputData, DbConn dbc) {

        StringData errorMsgs = new StringData();
        errorMsgs = validate(inputData);
        if (errorMsgs.getCharacterCount() > 0) {  // at least one field has an error, don't go any further.
            errorMsgs.errorMsg = "Please try again";
            return errorMsgs;

        } else { // all fields passed validation

           
            // Start preparing SQL statement
            String sql = "INSERT INTO food (food_id, food_name, web_user_id) "
                    + "values (?,?,?)";

            // PrepStatement is Sally's wrapper class for java.sql.PreparedStatement
            // Only difference is that Sally's class takes care of encoding null 
            // when necessary. And it also System.out.prints exception error messages.
            PrepStatement pStatement = new PrepStatement(dbc, sql);

            // Encode string values into the prepared statement (wrapper class).
            pStatement.setInt(1, ValidationUtils.integerConversion(inputData.foodId));
            pStatement.setString(2, inputData.foodName); // string type is simple
            pStatement.setInt(3, ValidationUtils.integerConversion(inputData.webUserId));

            // here the SQL statement is actually executed
            int numRows = pStatement.executeUpdate();

            // This will return empty string if all went well, else all error messages.
            errorMsgs.errorMsg = pStatement.getErrorMsg();
            if (errorMsgs.errorMsg.length() == 0) {
                if (numRows == 1) {
                    errorMsgs.errorMsg = ""; // This means SUCCESS. Let the user interface decide how to tell this to the user.
                } else {
                    // probably never get here unless you forgot your WHERE clause and did a bulk sql update.
                    errorMsgs.errorMsg = numRows + " records were inserted when exactly 1 was expected.";
                }
            } else if (errorMsgs.errorMsg.contains("foreign key")) {
                errorMsgs.errorMsg = "Invalid Web User ID";
            /*} else if (errorMsgs.errorMsg.contains("Duplicate entry")) {
                errorMsgs.errorMsg = "That email address is already taken";
            */}

        } // customerId is not null and not empty string.
        return errorMsgs;
    } // insert
    
    // method delete returns "" (empty string) if the delete worked fine. Otherwise, 
    // it returns an error message.
    public static String delete(String foodId, DbConn dbc) {

        if (foodId == null) {
            return "Error in modelwebUser.DbMods.delete: cannot delete web_user record because 'userId' is null";
        }

        // This method assumes that the calling Web API (JSP page) has already confirmed 
        // that the database connection is OK. BUT if not, some reasonable exception should 
        // be thrown by the DB and passed back anyway... 
        String result = ""; // empty string result means the delete worked fine.
        try {

            String sql = "DELETE FROM food WHERE food_id = ?";

            // This line compiles the SQL statement (checking for syntax errors against your DB).
            PreparedStatement pStatement = dbc.getConn().prepareStatement(sql);

            // Encode user data into the prepared statement.
            pStatement.setString(1, foodId);

            int numRowsDeleted = pStatement.executeUpdate();

            if (numRowsDeleted == 0) {
                result = "Record not deleted - there was no record with food_id " + foodId;
            } else if (numRowsDeleted > 1) {
                result = "Programmer Error: > 1 record deleted. Did you forget the WHERE clause?";
            }

        } catch (Exception e) {
            result = "Exception thrown in model.webUser.DbMods.delete(): " + e.getMessage();
        }

        return result;
    }//delete

}//class
