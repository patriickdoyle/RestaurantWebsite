package view;

// classes imported from java.sql.*
import model.id.StringDataList;
import model.id.StringData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

// classes in my project
import dbUtils.*;

public class IdView {

    public static StringDataList getAllIds(DbConn dbc) {

        StringDataList sdl = new StringDataList();
        try {
            String sql = "SELECT web_user_id, user_email "
                    + "FROM web_user ORDER BY user_email ";  // you always want to order by something, not just random order.
            PreparedStatement stmt = dbc.getConn().prepareStatement(sql);
            ResultSet results = stmt.executeQuery();
            while (results.next()) {

                StringData id = new StringData();
                id.webUserId = FormatUtils.formatInteger(results.getObject("web_user_id"));
                id.userEmail = FormatUtils.formatString(results.getObject("user_email"));
                sdl.add(id);
            }
            results.close();
            stmt.close();
        } catch (Exception e) {
            StringData sd = new StringData();
            sd.errorMsg = "Exception thrown in idView.allIdsAPI(): " + e.getMessage();
            sdl.add(sd);
        }
        return sdl;
    }
}